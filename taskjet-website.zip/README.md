# TaskJet Website

## Description
TaskJet is a platform where users can complete daily tasks, earn money, and upgrade through job levels. Includes referral system, recharge via M-Pesa, withdrawal with admin approval, and an admin dashboard.

## Features
- User registration and login with referral tracking
- Job levels with daily income and task video requirements
- Daily login bonus (Ksh 5)
- Recharge via M-Pesa message validation
- Withdrawal system with minimum amount and tax
- Referral earnings: 20%, 2%, 1% for levels 1, 2, and 3
- Admin dashboard secured by password "2025"
- Team section showing referrals
- Marquee display for recent recharges and withdrawals

## Setup Instructions

### Prerequisites
- Node.js (v16+)
- npm or yarn
- Firebase account (for auth and database) or MongoDB + backend setup

### Installation
1. Clone this repository
2. Run `npm install` to install dependencies
3. Create Firebase project and add config to `src/firebase.js` (or setup backend as needed)
4. Run `npm start` to start the development server

### Deployment
- Deploy frontend and backend on Render.com or any other free hosting service
- Set environment variables for Firebase or backend URLs

### Admin Access
- Access the admin dashboard by clicking on the balance 7 times (or as configured)
- Use password: **2025**

## Notes
- This is a simplified starter code; you will need to implement actual Firebase integration or backend API endpoints.
- The UI is basic and ready for styling with Tailwind CSS or similar.